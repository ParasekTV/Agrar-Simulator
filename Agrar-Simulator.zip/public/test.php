<?php
echo "PHP funktioniert!";
echo "<br>PHP Version: " . phpversion();
